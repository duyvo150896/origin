Include("\\script\\newbattles\\sign_up_npc.lua");

g_sNpcName = "M� Binh Quan phe T�ng";
g_nNpcCamp = SONG_ID;

function main()
	battle_main();
end;
