Include("\\script\\newbattles\\sign_up_npc.lua");

g_sNpcName = "M� Binh Quan phe Li�u";
g_nNpcCamp = LIAO_ID;

function main()
	battle_main();
end;