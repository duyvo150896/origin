Include("\\script\\equip_feed\\equip_feed_npc.lua")

function OnUse(nItemIdx)
	_equip_feed_do_chongzhu()
end