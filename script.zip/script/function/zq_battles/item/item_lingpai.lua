--XXX����
Include("\\script\\function\\zq_battles\\zq_head.lua")

function OnUse(nItem)
	ZQ_ReStartSeal_UseItem(nItem);
end