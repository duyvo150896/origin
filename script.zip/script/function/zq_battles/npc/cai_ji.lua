--�ɼ�ͨ�ýű�
Include("\\script\\function\\zq_battles\\zq_head.lua")

function main()
	ZQ_Gather();
end