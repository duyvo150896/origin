Include("\\script\\function\\zq_battles\\zq_head.lua")
function main()
	ZQ_ReStartSeal_UseItem();
end