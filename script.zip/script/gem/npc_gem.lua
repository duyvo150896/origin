Include("\\settings\\static_script\\gem\\imp_npc_gem.lua")

function main()
	gemNpcTalkMain()
end
