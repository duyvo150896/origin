Include("\\script\\online_activites\\2010_11\\activity_03\\head.lua")

function OnStoppingFakeGathering()
	--WriteLog("OnStoppingFakeGathering::called");
	GT_onStoppingFakeGathering();
end