
Include("\\script\\gongcheng\\personal_task\\task_head.lua")

function main()
	init_farm()
end