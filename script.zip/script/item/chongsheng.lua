function OnDeath(NpcIndex)
	SetNpcLifeTime(NpcIndex,0);
end;