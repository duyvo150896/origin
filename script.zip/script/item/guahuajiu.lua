
function OnUse()
	i=random(1,5000)
	ModifyExp(i)
	DelItem(2,0,189,1)
end;