#Dinh Hon Thien Thach
function OnUse(nItemIndex)
	
end

function do_nothing()
end