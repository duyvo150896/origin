Include("\\settings\\static_script\\item\\item_fushengdan_impl.lua")

function OnUse(nItemIdx)
	return on_use_xiulian(nItemIdx)
end