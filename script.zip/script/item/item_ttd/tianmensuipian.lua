--������Ƭʹ�ýű�
Include("\\settings\\static_script\\missions\\hunduantongtianding\\item\\item_tianmensuipian.lua")

function OnUse(nItem)
	TMSP_OnUse(nItem);
end
