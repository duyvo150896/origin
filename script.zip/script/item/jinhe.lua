
function OnUse()
	i=random(1,2000)
	Earn(i)
	DelItem(2,0,168,1)
end;