Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 110
g_mediname = "Kim S�ng T�n"