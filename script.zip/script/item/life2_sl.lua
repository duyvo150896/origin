Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 111
g_mediname = "Ch� Huy�t t�n"