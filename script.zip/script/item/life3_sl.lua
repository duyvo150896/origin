Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 112
g_mediname = "B�ch V�n ��n"