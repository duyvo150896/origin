Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 113
g_mediname = "Thi�n H��ng C�m T�c"