Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 114
g_mediname = "Ng�c Cao t�n"