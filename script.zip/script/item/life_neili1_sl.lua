Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 120
g_mediname = "Thanh T�m T�n"