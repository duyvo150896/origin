Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 121
g_mediname = "�ch Kh� T�n"