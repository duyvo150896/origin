Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 122
g_mediname = "Ng�c Linh T�n"