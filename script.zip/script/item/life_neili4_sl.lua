Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 123
g_mediname = "Ng�c L� Ho�n"