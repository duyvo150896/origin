Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 124
g_mediname = "Sinh Sinh H�a T�n"