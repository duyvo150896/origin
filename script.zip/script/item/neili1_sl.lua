Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 115
g_mediname = "Ti�u Ho�n ��n"