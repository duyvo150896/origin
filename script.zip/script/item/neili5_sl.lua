Include("\\script\\item\\sl_medicine_head.lua")
g_meditype = 119
g_mediname = "V�n V�t Quy Nguy�n ��n"