function OnUse()
	SendScript2VM("\\script\\biwudahui\\wlzb_award.lua","exchange()")
end

