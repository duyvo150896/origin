--Include by \settings\static_script\isolate\base\isolate_center_impl.lua

--an isolate is a module that do nothing with any other module,
--it implement all actions in one single file
--use isolate modle, you can impiment a module only in a single script file, do not need any other file modification

--refer: \script\isolate\functions\function_list.lua
--template isolate file refer : \script\isolate\functions\template\main.lua
--isolate useage example refer: \script\isolate\online_activites\every_month\main\main.lua

tIsolateListVNG = {
	--{enable, main_script_file, }
	--{1, "\\script\\isolate\\functions\\old_sys\\main.lua" },
}