--define named string id in \\script\\ks2vng\\lib\\managed_viet_string.ini
--id from 1 to 200000000-1 for VNG
--id from 200000000 to 2100000000 for kinsoft reserve

--below id reserve for vng
--see \\script\\lib\\managed_viet_string.ini
-----------------------------------------------------------------------------
VIET_STR_ID_VNG_BEGIN=1

VIET_STR_ID_VNG_END=2000000000-1
-----------------------------------------------------------------------------



--below id reserve for kingsoft
--see \\script\\lib\\no_trans\\managed_viet_string_ks.ini
-----------------------------------------------------------------------------
--VIET_STR_ID_KINGSOFT_BEGIN=2000000000
--VIET_STR_ID_MONEY_NOT_ENOUGH = VIET_STRING_ID_KINGSOFT_BEGIN + 0

--VIET_STR_ID_KINGSOFT_END=2100000000
-----------------------------------------------------------------------------

