-- Function to write log with VNG format
-- Created by TuanNA5
-- Created date 20/08/2008

Include("\\script\\lib\\globalfunctions.lua")