--ϴ����

Include("\\settings\\static_script\\meridian\\item_xichendan_imp.lua")

--\script\meridian\item_xichendan.lua
function OnUse(id)
	OnUse_Real(id)
end