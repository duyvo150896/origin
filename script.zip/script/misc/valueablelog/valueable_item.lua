Include("\\script\\ks2vng\\misc\\valueablelog\\valueable_item.lua")
