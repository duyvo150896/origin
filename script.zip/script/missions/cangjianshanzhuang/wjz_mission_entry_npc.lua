Include("\\settings\\static_script\\missions\\cangjianshanzhuang\\jt_npc.lua")

function main()
	return wjz_entry_npc_main()
end