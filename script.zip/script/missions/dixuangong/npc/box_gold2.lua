Include("\\script\\missions\\dixuangong\\npc\\box_gold.lua")

function main()
	on_open_dxg_box_gold(2)
end
