Include("\\script\\missions\\dixuangong\\npc\\box_tong.lua")

function main()
	on_open(2)
end

