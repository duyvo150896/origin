Include("\\script\\missions\\dixuangong\\npc\\box_yin.lua")
function main()
	on_open_box_yin()
end