Include("\\script\\missions\\dixuangong\\trap\\trap_head.lua");

TrapId = 2;
