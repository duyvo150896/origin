
function main()
	SendScript2VM("\\script\\missions\\dixuangong\\mission.lua", format("onTrap(%d)", TrapId));
end
