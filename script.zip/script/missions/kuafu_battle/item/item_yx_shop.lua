Include("\\script\\equip_shop\\equip_shop_head.lua")

function OnUse(nItem)
	show_equip_shop(3029);	
end