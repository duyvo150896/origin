function main()
	Sale(1);
end