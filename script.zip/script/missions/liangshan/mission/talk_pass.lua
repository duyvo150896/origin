function main(npcIdx)
	--test:��ʱ�޽ӿ�
	SendScript2VM("\\script\\missions\\liangshan\\mission\\mission.lua", "OnTalk2PassNpc")
end
