function OnTimer()
	SendScript2VM("\\script\\missions\\liangshan\\mission\\mission.lua", "OnTimer()")
end
