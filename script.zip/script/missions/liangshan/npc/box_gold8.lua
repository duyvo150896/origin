Include("\\script\\missions\\liangshan\\npc\\box_gold.lua")

function main()
	on_open_box_gold(8)
end
