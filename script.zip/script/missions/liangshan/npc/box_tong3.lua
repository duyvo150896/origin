Include("\\script\\missions\\liangshan\\npc\\box_tong.lua")

function main()
	on_open(3)
end

