id = 1;
Include("\\script\\missions\\liangshan\\trap\\trap_head.lua");
