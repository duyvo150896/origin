id = 2;
Include("\\script\\missions\\liangshan\\trap\\trap_head.lua");
