id = 5;
Include("\\script\\missions\\liangshan\\trap\\trap_head.lua");
