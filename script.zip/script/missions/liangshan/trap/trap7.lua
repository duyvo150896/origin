id = 7;
Include("\\script\\missions\\liangshan\\trap\\trap_head.lua");
