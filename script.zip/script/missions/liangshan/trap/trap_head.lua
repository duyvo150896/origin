function main(nSel)
	SendScript2VM("\\script\\missions\\liangshan\\mission\\mission.lua", "OnTrap("..nSel..","..id..")");
end
