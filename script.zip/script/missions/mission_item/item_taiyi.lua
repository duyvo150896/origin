function OnUse()
	-- body
	SendScript2Client(format("Open([[EquipShop]], %d, [[%s]])", 3079, "Ti�m danh v�ng Chi�t Xung X�"))
end