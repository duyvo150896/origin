Include("\\script\\lib\\globalfunctions.lua");

TEST_MODAL = 0;	--test

DebugOutput = nothing

--װ��������
_3V3_EQUIP_BLACKLISTS = {
		--G,D,P	
}
g_szInfoHead = "<color=green> ��c S� ��i H�i T� V� <color>:";

_3V3_LAST_WEEK_AWARD = {
	[1] = {
			[1] = {1,0},
			[2] = {1,0},
			[3] = {1,0},
			[4] = {1,0},	
			[5] = {2,0},
	},
	[2] = {
			[1] = {1,0},
			[2] = {1,0},
			[3] = {1,0},
			[4] = {2,0},	
			[5] = {2,0},
	},
	[3] = {
			[1] = {1,0},
			[2] = {1,0},
			[3] = {2,0},
			[4] = {2,1},	
			[5] = {2,2},
	},
	[4] = {
			[1] = {1,0},
			[2] = {2,0},
			[3] = {2,1},
			[4] = {3,1},	
			[5] = {3,2},
	},
}

