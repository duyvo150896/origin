function main()
	SendScript2VM("\\script\\missions\\nvn\\battle\\battle.lua", "onTrap(1)");
end
