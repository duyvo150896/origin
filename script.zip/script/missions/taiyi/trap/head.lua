function main()
	SendScript2VM("\\script\\missions\\taiyi\\mission.lua", format("OnTrap(%d)", 1));
end
