--date:2007-7-13 10:10
--author:yanjun
--describe:death script
function OnDeath(Launcher)
	local nKillerIdx = NpcIdx2PIdx(Launcher);
end;