
function main()
	SetFightState(0);
end