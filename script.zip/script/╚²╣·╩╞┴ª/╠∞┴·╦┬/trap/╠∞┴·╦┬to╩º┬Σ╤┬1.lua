Include("\\script\\missions\\yp\\qmy\\head.lua")

function main()
	yp_rebornBiaoche(6300,1596,3244);
end