Include("\\script\\missions\\yp\\qmy\\head.lua")

function main()
	yp_rebornBiaoche(6300,1528,3441);
end