Include("\\script\\missions\\yp\\qmy\\head.lua")

function main()
	yp_rebornBiaoche(6300,1400,2876);
end