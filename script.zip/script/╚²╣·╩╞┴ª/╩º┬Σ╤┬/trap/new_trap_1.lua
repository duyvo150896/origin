
function main()
	SetPos(1385,3314);
end