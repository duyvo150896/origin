
function main()
	SetPos(1432,3239);
end