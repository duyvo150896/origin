
function main()
	SetFightState(1);
end