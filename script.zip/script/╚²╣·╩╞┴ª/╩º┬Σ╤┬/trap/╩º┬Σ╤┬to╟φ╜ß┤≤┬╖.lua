Include("\\script\\missions\\yp\\hss\\entrynpc.lua")

function main()
	enter();
	SetPos(1896,3261);
	SetFightState(1);
end