Include("\\script\\missions\\yp\\hss\\entrynpc.lua")

function main()
	enter();
	SetPos(1771,3180);
	SetFightState(1);
end