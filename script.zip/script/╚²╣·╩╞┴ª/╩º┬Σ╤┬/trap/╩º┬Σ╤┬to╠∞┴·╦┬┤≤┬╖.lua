Include("\\script\\missions\\yp\\tls\\entrynpc.lua")

function main()
	enter();
	SetPos(1335,2590);
	SetFightState(1);
end