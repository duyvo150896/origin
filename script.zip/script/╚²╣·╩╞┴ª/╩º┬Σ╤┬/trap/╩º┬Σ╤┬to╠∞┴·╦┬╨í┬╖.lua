Include("\\script\\missions\\yp\\tls\\entrynpc.lua")

function main()
	enter();
	SetPos(1588,2589);
	SetFightState(1);
end