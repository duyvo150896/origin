Include("\\script\\missions\\yp\\mm\\entrynpc.lua")

function main()
	enter();
	SetPos(1394,3168);
	SetFightState(1);
end