Include("\\script\\missions\\yp\\mm\\entrynpc.lua")

function main()
	enter();
	SetPos(1520,3095);
	SetFightState(1);
end