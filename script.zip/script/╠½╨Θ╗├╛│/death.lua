
Include("\\script\\̫��þ�\\head.lua")

function OnDeath()
	
end
