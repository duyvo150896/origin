function main(sel)
	NewWorld(429,1631,3272)
	SetFightState(1);
end;