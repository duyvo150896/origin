function main(sel)
	NewWorld(420, 1405 ,3733)
	SetFightState(1);
end;