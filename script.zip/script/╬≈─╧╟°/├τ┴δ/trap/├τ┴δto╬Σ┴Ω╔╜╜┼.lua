function main(sel)
	NewWorld(405, 1286 ,3198)
	SetFightState(1);
end;