function main(sel)
	SetFightState(1);
end;