function main(sel)
	NewWorld(405, 1285 ,2822)
	SetFightState(1);
end;