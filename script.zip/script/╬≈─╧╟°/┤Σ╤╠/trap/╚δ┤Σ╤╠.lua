function main(sel)
	SetFightState(0);
end;