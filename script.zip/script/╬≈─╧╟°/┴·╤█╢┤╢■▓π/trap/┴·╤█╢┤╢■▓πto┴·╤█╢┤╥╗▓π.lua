function main(sel)
	NewWorld(412, 1549 ,3104)
	SetFightState(1);
end;