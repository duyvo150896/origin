function main(sel)
	NewWorld(413, 1894 ,3397)
	SetFightState(1);
end;