function main(sel)
	NewWorld(401, 1476 ,2887)
	SetFightState(1);
end;