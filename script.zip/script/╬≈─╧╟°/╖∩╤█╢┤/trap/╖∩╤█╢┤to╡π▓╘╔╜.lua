function main(sel)
	NewWorld(401, 1654 ,2773)
	SetFightState(1);
end;