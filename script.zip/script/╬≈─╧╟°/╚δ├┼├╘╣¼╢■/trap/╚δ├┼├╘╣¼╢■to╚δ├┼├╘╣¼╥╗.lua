function main(sel)
	NewWorld(418, 1706 ,2649)
	SetFightState(1);
end;