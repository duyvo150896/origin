function main(sel)
	NewWorld(407, 1435 ,3078)
	SetFightState(1);
end;