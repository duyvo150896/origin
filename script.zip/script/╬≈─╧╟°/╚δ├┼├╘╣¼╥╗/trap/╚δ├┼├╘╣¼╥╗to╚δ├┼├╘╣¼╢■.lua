function main(sel)
	NewWorld(419, 1714 ,3443)
	SetFightState(1);
end;