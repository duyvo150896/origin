function main(sel)
	NewWorld(414, 1627 ,3535)
	SetFightState(1);
end;