function main(sel)
	NewWorld(420, 1633 ,3454)
	SetFightState(1);
end;