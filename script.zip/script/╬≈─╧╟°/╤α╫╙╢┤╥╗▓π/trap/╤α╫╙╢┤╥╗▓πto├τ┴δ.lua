function main(sel)
	NewWorld(408, 1297 ,2707)
	SetFightState(1);
end;