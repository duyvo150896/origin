function main(sel)
	NewWorld(421, 1559 ,3457)
	SetFightState(1);
end;