function main(sel)
	NewWorld(428,1381,2524)
	SetFightState(1);
end;