function main(sel)
	NewWorld(405, 1559 ,2756)
	SetFightState(1);
end;