function main(sel)
	NewWorld(408,1572,2759)
	SetFightState(1);
end;