function main(sel)
	NewWorld(404,1656,3217)
	SetFightState(1);
end;