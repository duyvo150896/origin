function main(sel)
	NewWorld(406,1284,3166)
	SetFightState(1);
end;