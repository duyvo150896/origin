function main(sel)
	NewWorld(407,1553,3072)
	SetFightState(1);
end;