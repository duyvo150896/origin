function main(sel)
	NewWorld(426, 1569 ,2901)
	SetFightState(0);
end;