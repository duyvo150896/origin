function main(sel)
	NewWorld(105, 1398 ,2892)
	SetFightState(1);
end;