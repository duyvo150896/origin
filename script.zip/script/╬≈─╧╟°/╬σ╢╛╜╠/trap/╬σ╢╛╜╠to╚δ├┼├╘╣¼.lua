function main(sel)
	NewWorld(418, 1552 ,3205)
	SetFightState(1);
end;