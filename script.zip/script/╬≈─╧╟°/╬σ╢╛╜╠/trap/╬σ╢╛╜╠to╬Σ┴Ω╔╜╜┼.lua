function main(sel)
	NewWorld(405, 1577 ,3063)
	SetFightState(1);
end;