function main(sel)
	NewWorld(402, 1301 ,3160)
	SetFightState(1);
end;