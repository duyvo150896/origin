function main(sel)
	NewWorld(401, 1573 ,3259)
	SetFightState(1);
end;