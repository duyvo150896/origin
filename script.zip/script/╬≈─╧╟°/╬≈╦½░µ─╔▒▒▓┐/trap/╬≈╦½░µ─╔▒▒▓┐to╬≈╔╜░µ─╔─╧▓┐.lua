function main(sel)
	NewWorld(403, 1579 ,2951)
	SetFightState(1);
end;