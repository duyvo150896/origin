function main(sel)
	NewWorld(416, 1887 ,2809)
	SetFightState(1);
end;