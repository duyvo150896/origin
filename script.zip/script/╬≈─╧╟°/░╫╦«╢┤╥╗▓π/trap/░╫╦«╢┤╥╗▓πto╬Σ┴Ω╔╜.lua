function main(sel)
	NewWorld(406, 1306 ,2739)
	SetFightState(1);
end;