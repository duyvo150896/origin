function main(sel)
	NewWorld(417, 1606 ,3611)
	SetFightState(1);
end;