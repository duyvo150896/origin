
function main(sel)
	NewWorld(516, 1625, 3113);
	SetFightState(1);
end