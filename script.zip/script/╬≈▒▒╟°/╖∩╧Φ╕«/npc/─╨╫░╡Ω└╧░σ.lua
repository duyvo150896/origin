function main()
			Sale(43)
end;