
function main()

	Sale(37)
	
end;