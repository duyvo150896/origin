
-- ====================== �ļ���Ϣ ======================

-- ������ԵonlineII �ӻ����ϰ�ű�
-- Edited by peres
-- 2005/02/22 PM 18:03

-- ======================================================

function main()

		i = random(1,3)
		if (i == 1) then
			Sale(35)
		elseif (i == 2) then
			Sale(35)
		else
			Sale(35)
		end
end;
