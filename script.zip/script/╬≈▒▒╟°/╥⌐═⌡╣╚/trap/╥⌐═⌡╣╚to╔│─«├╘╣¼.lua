--ҩ����toʥ���
Include("\\script\\missions\\yp\\tls\\entrynpc.lua")

function main()
NewWorld(506, 1504 ,3141)
	SetFightState(1);
end
