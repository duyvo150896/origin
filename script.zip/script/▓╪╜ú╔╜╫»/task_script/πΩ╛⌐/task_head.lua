
SERVER_INDEX = 2
Include("\\script\\�ؽ�ɽׯ\\task_script\\task_head.lua")
