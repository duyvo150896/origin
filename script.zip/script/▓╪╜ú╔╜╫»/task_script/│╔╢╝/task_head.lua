
SERVER_INDEX = 1
Include("\\script\\�ؽ�ɽׯ\\task_script\\task_head.lua")
