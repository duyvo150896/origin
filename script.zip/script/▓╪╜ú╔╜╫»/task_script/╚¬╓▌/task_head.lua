
SERVER_INDEX = 3
Include("\\script\\�ؽ�ɽׯ\\task_script\\task_head.lua")
