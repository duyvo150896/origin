
SERVER_INDEX = 5
Include("\\script\\�ؽ�ɽׯ\\task_script\\task_head.lua")
