
SERVER_INDEX = 4
Include("\\script\\�ؽ�ɽׯ\\task_script\\task_head.lua")
