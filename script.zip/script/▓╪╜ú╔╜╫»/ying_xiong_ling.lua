
function yxl_killed()
    
end