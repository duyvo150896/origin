function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1554,3263)
end;