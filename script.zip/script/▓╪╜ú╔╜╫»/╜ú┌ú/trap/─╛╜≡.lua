function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1492,3168)
end;