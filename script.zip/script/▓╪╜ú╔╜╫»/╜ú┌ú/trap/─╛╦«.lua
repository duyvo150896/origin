function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1601,3392)
end;