function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1573,3219)
end;