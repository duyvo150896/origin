function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1519,3148)
end;