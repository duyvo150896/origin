function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1493,3339)
end;