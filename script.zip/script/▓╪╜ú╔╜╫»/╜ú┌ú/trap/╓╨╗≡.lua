function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1668,3221)
end;