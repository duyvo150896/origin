function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1512,3170)
end;