function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1598,3358)
end;