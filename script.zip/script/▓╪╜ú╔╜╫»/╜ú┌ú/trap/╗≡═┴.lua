function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1604,3110)
end;