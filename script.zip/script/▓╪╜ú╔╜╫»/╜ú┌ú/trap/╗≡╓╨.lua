function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1594,3238)
end;