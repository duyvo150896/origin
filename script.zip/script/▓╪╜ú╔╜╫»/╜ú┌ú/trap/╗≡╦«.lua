function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1615,3352)
end;