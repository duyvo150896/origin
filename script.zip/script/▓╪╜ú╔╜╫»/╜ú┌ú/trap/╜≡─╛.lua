function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1477,3319)
end;