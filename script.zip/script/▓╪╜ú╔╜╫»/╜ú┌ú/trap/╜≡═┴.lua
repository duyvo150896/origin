function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1576,3120)
end;