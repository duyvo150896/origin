function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1545,3234)
end;