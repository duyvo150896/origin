function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1472,3358)
end;