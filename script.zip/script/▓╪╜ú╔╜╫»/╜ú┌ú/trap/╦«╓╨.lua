function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1576,3263)
end;