function main()
	a,b,c=GetWorldPos()
	NewWorld(a,1675,3238)
end;